function Footer() {
    // const navigate = useNavigate();
    // const id = useParams().id;
    return (
        <div style={{backgroundColor:"red", marginBottom:"0px", height: "39px", color: "white"}}>
            <p style={{fontSize:"19px", marginLeft:"550px"}}>Copyright &copy; 2024 TableReserve &middot; All rights reserved. </p>
        </div>
    );
}

export default Footer;