import { Link, useNavigate, useParams } from 'react-router-dom';
import PageLayout from '../components/layout/PageLayout';
import chaman from "../assets/icons/chaman.jpg";
import khoroos from "../assets/icons/khoroos.jpg";
import shila from "../assets/icons/shila.jpg";
import loc from "../assets/icons/free-location-icon.png";
import fastfood from "../assets/icons/fastfood.png";
import clock from "../assets/icons/clock.png";
import review from "../assets/icons/review.png";
import Stars from "../components/home/Stars";
import Comment from "../components/restaurant/Comment";
import React, { useState } from 'react';



const user = {
    id: 1,
    username: 'Farnamz',
    email: 'farnam1104@gmail.com',
};

const restaurants = [
    {
        id: 1,
        name: 'Shila',
        type: 'Fast Food',
        startTime: '08:00',
        endTime: '21:00',
        description: 'Yo yo description',
        address: {
            country: 'Iran',
            city: 'Tehran',
            street: 'Harja!',
        },
        averageRating: {
            food: 4,
            service: 4,
            ambiance: 3,
            overall: 4,
        },
        maxSeatsNumber: 15,
        starCount: 4,
        managerUsername: 'Misagh',
        image: 'shilaimage',
        totalReviews: 1,
    },
    {
        id: 2,
        name: 'Khoroos',
        type: 'Fast Food',
        startTime: '12:00',
        endTime: '24:00',
        description: 'Morgh sokhari e khoshmaze',
        address: {
            country: 'Iran',
            city: 'Tehran',
            street: 'Andarzgoo',
        },
        averageRating: {
            food: 5,
            service: 5,
            ambiance: 5,
            overall: 5,
        },
        maxSeatsNumber: 2,
        starCount: 5,
        managerUsername: 'Morgh',
        image: 'khoroosimage',
        totalReviews: 2,
    },
    {
        id: 3,
        name: 'Chaman',
        type: 'Fast Food',
        startTime: '11:00',
        endTime: '23:00',
        description: 'Zhambon tanoori vaaaay',
        address: {
            country: 'Iran',
            city: 'Tehran',
            street: 'Niavaran',
        },
        averageRating: {
            food: 5,
            service: 3,
            ambiance: 4,
            overall: 4,
        },
        maxSeatsNumber: 10,
        starCount: 4,
        managerUsername: 'Park',
        image: 'chamanimage',
        totalReviews: 3,
    }
]

const comments = [
    {
        rating: {
            food: 5,
            service: 4,
            ambiance: 4,
            overall: 5,
        },
        starCount: 5,
        comment: 'Perfection.',
        datetime: '2024-08-25 19:45:32',
        user: {
            id: 1,
            username: 'Farnam1',
            email: 'farnam1@gmail.com',
        },
    },
    {
        rating: {
            food: 4,
            service: 3,
            ambiance: 4,
            overall: 5,
        },
        starCount: 4,
        comment: 'That was gooooood!',
        datetime: '2024-08-24 19:45:32',
        user: {
            id: 2,
            username: 'Farnam2',
            email: 'farnam2@gmail.com',
        },
    },
    {
        rating: {
            food: 3,
            service: 2,
            ambiance: 4,
            overall: 3,
        },
        starCount: 3,
        comment: 'Ok!',
        datetime: '2024-08-15 19:45:32',
        user: {
            id: 3,
            username: 'Farnam3',
            email: 'farnam3@gmail.com',
        },
    },
    {
        rating: {
            food: 4,
            service: 4,
            ambiance: 4,
            overall: 4,
        },
        starCount: 4,
        comment: 'Ummmmm!',
        datetime: '2024-07-25 19:45:32',
        user: {
            id: 4,
            username: 'Farnam4',
            email: 'farnam4@gmail.com',
        },
    },
    {
        rating: {
            food: 5,
            service: 5,
            ambiance: 5,
            overall: 5,
        },
        starCount: 5,
        comment: 'YUuuumummdlgngnaineakfaf;oqmeqmflknfqekgnlqgkngnwg!!!!!!!!!',
        datetime: '2024-08-24 02:45:32',
        user: {
            id: 5,
            username: 'Fatnam5',
            email: 'farnam5@gmail.com',
        },
    },
    {
        rating: {
            food: 1,
            service: 1,
            ambiance: 1,
            overall: 1,
        },
        starCount: 1,
        comment: 'In che ashghali boof!',
        datetime: '2024-08-20 19:45:32',
        user: {
            id: 6,
            username: 'Nafarnam6',
            email: 'farnam6@gmail.com',
        },
    }
]

function Restaurant() {
    // const navigate = useNavigate();
    const id = useParams().id;
    let imag = "";
    if (id == "1") {
        imag = shila;
    }
    else if (id == "2") {
        imag = khoroos;
    }
    else {
        imag = chaman;
    }

    let marg = "";
    if (id == "1") {
        marg = "336px";
    }
    else if (id == "2") {
        marg = "284px";
    }
    else {
        marg = "287px";
    }

    let title = restaurants[parseInt(id) - 1].name;
    let reviews = restaurants[parseInt(id) - 1].totalReviews + " reviews";
    let kind = restaurants[parseInt(id) - 1].type;
    let location = restaurants[parseInt(id) - 1].address.country + "," + restaurants[parseInt(id) - 1].address.city + "," + restaurants[parseInt(id) - 1].address.street;
    let star = restaurants[parseInt(id) - 1].starCount;
    let linkres = '/restaurant/' + id;
    let clocktime = "From " + restaurants[parseInt(id) - 1].startTime + " to " + restaurants[parseInt(id) - 1].endTime;
    let description = restaurants[parseInt(id) - 1].description;
    let base = 0;
    if (parseInt(id) == 2) {
        base = 1;
    }
    else if (parseInt(id) == 3) {
        base = 3;
    }   
    let h = 0;

    let dateok = false;

    //TODO

    // let datenow = new Date();
    // const [value, setValue] = useState('');
    // const handleChange = (event) => {
    //     setValue(event.target.value);
    //     if (datenow > value){
    //         console.log("retere");
    //         dateok = true;
    //     }
    // };


    let starttime = restaurants[parseInt(id) - 1].startTime;
    let endtime = restaurants[parseInt(id) - 1].endTime;

    let es = starttime.split(":");
    let starthour = parseInt(es[0]);
    let es2 = endtime.split(":");
    let endhour = parseInt(es2[0]);

    let isOpen = true;
    var currentdate = new Date();

    if (parseInt(currentdate.getHours()) < starthour || parseInt(currentdate.getHours()) >= endhour) {
        isOpen = false;
    }
    // isOpen = false;

    let canReserve = false;

    return (
        <PageLayout>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div>
                    <div style={{ display: "flex", position: "absolute", backgroundColor: "#ffffff88", marginTop: "315px", marginLeft: "150px" }}>
                        <h1 style={{ paddingLeft: "20px" }}>{title}</h1>
                        <p style={{ paddingTop: "14px", marginLeft: marg, paddingRight: "20px" }}>
                            {isOpen ? (
                                <button style={{ color: "white", backgroundColor: "green", border: "2px solid transparent", height: "30px", borderRadius: "3ch" }}>Open!</button>
                            ) : (
                                <button style={{ color: "white", backgroundColor: "red", border: "2px solid transparent", height: "30px", borderRadius: "3ch" }}>Closed!</button>
                            )}
                        </p>
                    </div>
                    <img src={imag} width={"500px"} style={{ height: "300px", marginLeft: "150px", marginTop: "100px" }} />
                    <div style={{ display: "flex", marginLeft: "150px", justifyContent: "space-between" }}>
                        <p><img src={clock} style={{ width: "15px" }} /> {clocktime} </p>
                        <p><img src={review} style={{ width: "15px" }} /> {reviews} </p>
                        <p><img src={fastfood} style={{ width: "15px" }} /> {kind} </p>
                    </div>
                    <p style={{ color: "gray" }}><img src={loc} style={{ width: "15px", marginLeft: "150px" }} /> {location} </p>
                    <p style={{ marginLeft: "150px" }}>{description}</p>
                </div>
                <div style={{marginLeft:"40px"}}>
                    <h1 style={{ marginTop: "90px", marginRight: "600px" }}>Reserve Table</h1>
                    <p>For &nbsp;
                        <select name='numberreserve' id='numberreserve'>
                            {[...Array(parseInt(restaurants[parseInt(id) - 1].maxSeatsNumber))].map((_, i) => (
                                <option>{parseInt(i) + 1}</option>
                            ))}
                        </select>
                        &nbsp; people, on date &nbsp;
                        <input type="date" id="datereserve" name="datereserve" /><br></br>
                    </p>
                    <p>Available Times:<br></br>
                        {[...Array(endhour - starthour)].map((_, i) => (
                            <input type="button" value={String(starthour + i) + ":00"} style={{marginTop:"10px", marginLeft:"10px", backgroundColor: "white", border: "1px solid red", color: "red", height: "25px", width: "180px", borderRadius: "1ch", cursor:"pointer"}} />
                        ))}
                    </p>
                    <h5 style={{ color: "red" }}>You will reserve this table only for <u>one</u> hour, for more time please contact the restaurant.</h5>
                    {canReserve ? (
                        <button style={{ width: "600px", border: "0px", cursor: "pointer", height: "40px", borderRadius: "3ch", color: "white", fontSize: "17px", backgroundColor: "black" }}>Complete the Reservation</button>
                    ) : (
                        <button style={{ width: "600px", border: "0px", height: "40px", borderRadius: "3ch", color: "white", fontSize: "17px" }}>Complete the Reservation</button>
                    )}
                    {dateok && <h5 style={{ color: "red" }}>Please enter a date from future!</h5>}
                </div>
            </div>
            <div style={{ display: "flex", marginLeft: "150px", backgroundColor: "pink", marginRight: "200px", justifyContent: "space-between" }}>
                <div>
                    <h4 style={{ paddingLeft: "10px" }}>What {reviews} people are saying:</h4>
                    <div style={{ width: "290px", display: "flex", paddingBottom: "10px", paddingLeft: "10px" }}>
                        <Stars count={star} />
                        &nbsp; {star} based on recent ratings
                    </div>
                </div>
                <div style={{ display: "flex" }}>
                    <div style={{ marginRight: "30px" }}>
                        <p>Food</p>
                        <p style={{ marginLeft: "12px" }}>{restaurants[parseInt(id) - 1].averageRating.food}</p>
                    </div>
                    <div style={{ marginRight: "30px" }}>
                        <p>Service</p>
                        <p style={{ marginLeft: "20px" }}>{restaurants[parseInt(id) - 1].averageRating.service}</p>
                    </div>
                    <div style={{ marginRight: "30px" }}>
                        <p>Ambiance</p>
                        <p style={{ marginLeft: "30px" }}>{restaurants[parseInt(id) - 1].averageRating.ambiance}</p>
                    </div>
                    <div style={{ marginRight: "30px" }}>
                        <p>Overall</p>
                        <p style={{ marginLeft: "20px" }}>{restaurants[parseInt(id) - 1].averageRating.overall}</p>
                    </div>
                </div>
            </div>
            <div style={{ marginTop: "20px", display: "flex", justifyContent: "space-between", marginLeft: "150px", marginRight: "200px" }}>
                <h4>{reviews}</h4>
                <button style={{ marginTop: "10px", width: "150px", border: "0px", cursor: "pointer", height: "40px", borderRadius: "1ch", color: "white", fontSize: "17px", backgroundColor: "red" }}>Add Review</button>
                {/* TODO: Add review modal */}
            </div>
            <div style={{ marginTop: "20px", marginLeft: "150px", marginRight: "200px" }}>
                {[...Array(parseInt(restaurants[parseInt(id) - 1].totalReviews))].map((_, i) => (
                    <Comment id={(i) + base} />
                ))}
            </div>
        </PageLayout>
    );

}

export default Restaurant;